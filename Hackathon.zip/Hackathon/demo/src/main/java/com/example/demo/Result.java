
package com.example.demo;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class Result {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private Student student;

    @ManyToOne
    private Quiz quiz;

    private int marks;

    public Result() {
    }

    public Result(Student student, Quiz quiz, int marks) {
        this.student = student;
        this.quiz = quiz;
        this.marks = marks;
    }

    public Long getId() {
        return id;
    }

    public Student getStudent() {
        return student;
    }

    public Quiz getQuiz() {
        return quiz;
    }

    public int getMarks() {
        return marks;
    }

    public void setMarks(int marks) {
        this.marks = marks;
    }

    public String getStatus() {
        if (marks >= quiz.getPassMark()) {
            return "PASS";
        } else {
            return "FAIL";
        }
    }
}

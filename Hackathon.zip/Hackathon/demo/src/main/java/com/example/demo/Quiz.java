
package com.example.demo;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Quiz {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;

    private int maxMarks;

    private int passMark;

    public Quiz() {
    }

    public Quiz(String title, int maxMarks, int passMark) {
        this.title = title;
        this.maxMarks = maxMarks;
        this.passMark = passMark;
    }

    public Long getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public int getMaxMarks() {
        return maxMarks;
    }

    public int getPassMark() {
        return passMark;
    }
}

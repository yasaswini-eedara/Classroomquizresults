
package com.example.demo;

import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class QuizController {

    private final StudentRepository studentRepository;
    private final QuizRepository quizRepository;
    private final ResultRepository resultRepository;

    public QuizController(StudentRepository studentRepository,
                          QuizRepository quizRepository,
                          ResultRepository resultRepository) {
        this.studentRepository = studentRepository;
        this.quizRepository = quizRepository;
        this.resultRepository = resultRepository;
    }

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("students", studentRepository.findAll());
        model.addAttribute("quizzes", quizRepository.findAll());
        return "index";
    }

    @PostMapping("/addStudent")
    public String addStudent(@RequestParam String name) {
        if (name != null && !name.trim().isEmpty()) {
            studentRepository.save(new Student(name.trim()));
        }
        return "redirect:/";
    }

    @PostMapping("/addQuiz")
    public String addQuiz(@RequestParam String title,
                          @RequestParam int maxMarks,
                          @RequestParam int passMark) {
        if (title != null && !title.trim().isEmpty()
                && maxMarks > 0
                && passMark >= 0 && passMark <= maxMarks) {
            quizRepository.save(
                new Quiz(title.trim(), maxMarks, passMark)
            );
        }
        return "redirect:/";
    }

    @PostMapping("/addMarks")
    public String addMarks(@RequestParam Long studentId,
                           @RequestParam Long quizId,
                           @RequestParam int marks) {

        Student student =
            studentRepository.findById(studentId).orElse(null);

        Quiz quiz =
            quizRepository.findById(quizId).orElse(null);

        if (student == null || quiz == null ||
                marks < 0 || marks > quiz.getMaxMarks()) {
            return "redirect:/";
        }

        Result result =
            resultRepository.findByStudentIdAndQuizId(studentId, quizId);

        if (result == null) {
            result = new Result(student, quiz, marks);
        } else {
            result.setMarks(marks);
        }

        resultRepository.save(result);
        return "redirect:/";
    }

    @GetMapping("/results/{id}")
    public String results(@PathVariable Long id, Model model) {

        Quiz quiz = quizRepository.findById(id).orElse(null);

        if (quiz == null) {
            return "redirect:/";
        }

        List<Result> results = resultRepository.findByQuizId(id);

        double average = results.stream()
            .mapToInt(Result::getMarks)
            .average()
            .orElse(0.0);

        int highest = results.stream()
            .mapToInt(Result::getMarks)
            .max()
            .orElse(0);

        int lowest = results.stream()
            .mapToInt(Result::getMarks)
            .min()
            .orElse(0);

        model.addAttribute("quiz", quiz);
        model.addAttribute("results", results);
        model.addAttribute("average", String.format("%.2f", average));
        model.addAttribute("highest", highest);
        model.addAttribute("lowest", lowest);

        return "results";
    }
}


package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ResultRepository
        extends JpaRepository<Result, Long> {

    List<Result> findByQuizId(Long quizId);

    Result findByStudentIdAndQuizId(Long studentId, Long quizId);
}

import java.util.*;

class Student {
    int id;
    String name;

    Student(int id, String name) {
        this.id = id;
        this.name = name;
    }
}

class Quiz {
    int id;
    String title;
    int maxMarks;
    int passMark;
    Map<Integer, Integer> marks = new HashMap<>();

    Quiz(int id, String title, int maxMarks, int passMark) {
        this.id = id;
        this.title = title;
        this.maxMarks = maxMarks;
        this.passMark = passMark;
    }
}

public class ClassroomQuizSystem {
    static Scanner sc = new Scanner(System.in);
    static ArrayList<Student> students = new ArrayList<>();
    static ArrayList<Quiz> quizzes = new ArrayList<>();
    static int nextStudentId = 1;
    static int nextQuizId = 1;

    public static void main(String[] args) {
        int choice;

        do {
            System.out.println("\n===== CLASSROOM QUIZ RESULTS SYSTEM =====");
            System.out.println("1. Create Quiz");
            System.out.println("2. Add Student");
            System.out.println("3. Record Student Marks");
            System.out.println("4. View Quiz Results");
            System.out.println("5. View Quiz Statistics");
            System.out.println("6. View All Students and Quizzes");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");

            choice = readInt();

            switch (choice) {
                case 1: createQuiz(); break;
                case 2: addStudent(); break;
                case 3: recordMarks(); break;
                case 4: viewResults(); break;
                case 5: viewStatistics(); break;
                case 6: viewRecords(); break;
                case 0: System.out.println("Thank you!"); break;
                default: System.out.println("Invalid choice. Try again.");
            }
        } while (choice != 0);
    }

    static int readInt() {
        while (!sc.hasNextInt()) {
            System.out.print("Please enter a valid number: ");
            sc.next();
        }
        int value = sc.nextInt();
        sc.nextLine();
        return value;
    }

    static void createQuiz() {
        System.out.print("Enter quiz title: ");
        String title = sc.nextLine().trim();

        System.out.print("Enter maximum marks: ");
        int max = readInt();

        if (title.isEmpty() || max <= 0) {
            System.out.println("Title and maximum marks must be valid.");
            return;
        }

        System.out.print("Enter pass mark: ");
        int pass = readInt();

        if (pass < 0 || pass > max) {
            System.out.println("Pass mark must be between 0 and maximum marks.");
            return;
        }

        quizzes.add(new Quiz(nextQuizId++, title, max, pass));
        System.out.println("Quiz created successfully.");
    }

    static void addStudent() {
        System.out.print("Enter student name: ");
        String name = sc.nextLine().trim();

        if (name.isEmpty()) {
            System.out.println("Student name cannot be empty.");
            return;
        }

        students.add(new Student(nextStudentId++, name));
        System.out.println("Student added successfully. Student ID: " + (nextStudentId - 1));
    }
     static Student findStudent(int id) {
        for (Student s : students) {
            if (s.id == id) return s;
        }
        return null;
    }

    static Quiz findQuiz(int id) {
        for (Quiz q : quizzes) {
            if (q.id == id) return q;
        }
        return null;
    }

    static void showStudents() {
        System.out.println("\nStudents:");
        for (Student s : students) {
            System.out.println(s.id + " - " + s.name);
        }
    }

    static void showQuizzes() {
        System.out.println("\nQuizzes:");
        for (Quiz q : quizzes) {
            System.out.println(q.id + " - " + q.title +
                    " (Max: " + q.maxMarks + ", Pass: " + q.passMark + ")");
        }
    }

    static void recordMarks() {
        if (students.isEmpty() || quizzes.isEmpty()) {
            System.out.println("Add at least one student and create a quiz first.");
            return;
        }

        showStudents();
        System.out.print("Enter student ID: ");
        int studentId = readInt();
        Student student = findStudent(studentId);

        showQuizzes();
        System.out.print("Enter quiz ID: ");
        int quizId = readInt();
        Quiz quiz = findQuiz(quizId);

        if (student == null || quiz == null) {
            System.out.println("Invalid student ID or quiz ID.");
            return;
        }

        System.out.print("Enter marks obtained: ");
        int marks = readInt();

        if (marks < 0 || marks > quiz.maxMarks) {
            System.out.println("Marks must be between 0 and " + quiz.maxMarks + ".");
            return;
        }

        quiz.marks.put(studentId, marks);
        System.out.println("Marks recorded successfully.");
    }

    static void viewResults() {
        if (quizzes.isEmpty()) {
            System.out.println("No quizzes available.");
            return;
        }

        showQuizzes();
        System.out.print("Enter quiz ID to view results: ");
        Quiz quiz = findQuiz(readInt());

        if (quiz == null) {
            System.out.println("Quiz not found.");
            return;
        }

        System.out.println("\nResults for: " + quiz.title);
        System.out.printf("%-8s %-20s %-12s %-10s%n",
                "ID", "Student", "Marks", "Result");
        System.out.println("------------------------------------------------");

        for (Student s : students) {
            if (quiz.marks.containsKey(s.id)) {
                int marks = quiz.marks.get(s.id);
                String result = marks >= quiz.passMark ? "PASS" : "FAIL";
                System.out.printf("%-8d %-20s %-12d %-10s%n",
                        s.id, s.name, marks, result);
            } else {
                System.out.printf("%-8d %-20s %-12s %-10s%n",
                        s.id, s.name, "Not entered", "Pending");
            }
        }
    }

    static void viewStatistics() {
        if (quizzes.isEmpty()) {
            System.out.println("No quizzes available.");
            return;
        }

        showQuizzes();
        System.out.print("Enter quiz ID: ");
        Quiz quiz = findQuiz(readInt());

        if (quiz == null) {
            System.out.println("Quiz not found.");
            return;
        }

        if (quiz.marks.isEmpty()) {
            System.out.println("No marks have been entered for this quiz.");
            return;
        }

        int highest = Integer.MIN_VALUE;
        int lowest = Integer.MAX_VALUE;
        int total = 0;

        for (int mark : quiz.marks.values()) {
            highest = Math.max(highest, mark);
            lowest = Math.min(lowest, mark);
            total += mark;
        }

        double average = (double) total / quiz.marks.size();

        System.out.println("\nStatistics for: " + quiz.title);
        System.out.println("Students with marks: " + quiz.marks.size());
        System.out.println("Highest marks: " + highest);
        System.out.println("Lowest marks : " + lowest);
        System.out.printf("Average marks : %.2f%n", average);
    }

    static void viewRecords() {
        showStudents();
        showQuizzes();
    }
}